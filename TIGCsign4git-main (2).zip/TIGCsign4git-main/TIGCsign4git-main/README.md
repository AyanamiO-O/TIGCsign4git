# TIGCsign4git
Edit the text under "Deveoper":
  - who are you?(use your nick name and contact me on wechat)
  > and maybe you want to say something?

  (leave a blank line above please)

Developer:
  - Mamba
  > Maybe the next developer won`t use Japanese as his or her introduction? Never mind! 😜

  - Ayanami Rei
  > 神に挑むこと自体が…無謀…

  - Chicken so beautiful
  > 君も自分の加藤恵に出会えますように

  - Kun
  > 这些家伙……在说些什么呢……

  - When I see you again
  > 私の超電磁砲永世生き

  - What can I say
  > 我吐出每一个字都是明码标价的 邪恶的 是难以置信的

  - liaoliao
  > 也许我只是疯了。也许还严重一些。

  - iix
  > oi!今天花生什么大树了？

  - yxlikely
  > 嗝儿~~~~~~

  - Ansinwind
  > 好想变成人类啊，但是主不理人:<

  - p3rm1t
  > Make TIGC Great Again


 - ladygege
  > I am myself.

 - Sevepu
  >阿巴阿巴 

 - Layllla
  >怎么没有妹子和我过七夕

  It is probably because you don`t want to. 🌠🌠🌠
  >人机大战。。。险胜。。。

  - HL
  > 呆胶布？

